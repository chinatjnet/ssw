<?php

// Plazza Date   
// By Andy Sikumbang 
// http://www.templateplazza.com
// Copyright (C) 2007 TemplatePlazza.com
// License http://www.gnu.org/copyleft/gpl.html GNU/GPL
// no direct access
defined( '_VALID_MOS' ) or die( 'Restricted access' );
$wrapperbox  = $params->get( 'wrapperbox','width:auto; background:#FFFFFF; float:right; border:#333333; text-align:center;
padding:7px 7px;
border-width:0 1px 1px 0;
border-style:solid;
border-color:#000000 #D68330 #D68330 #fff' );
$month_setting = $params->get( 'month_setting','font-size:12px; font-weight:bold; text-transform:lowercase; line-height:97%; font-family:arial; color:#fff; background:#999; padding:2px;' );
$date_setting = $params->get( 'date_setting','font-size:32px;  line-height:90%;font-family:arial; color:#333; font-weight:bold;');
$year_setting = $params->get(  'year_setting','font-size:12px;line-height:97%;font-family:arial; color:#000000;');
$badgeuse = $params->get ( 'badgeuse','0');
$badge_setting = $params->get( 'badge_setting','position:absolute; margin-left:-50px; margin-top:-70px;');
$badge_image = $params->get ( 'badge_image','today_black.gif');
?>

<!-- Calendar Date by http://www.templateplazza.com - Simple Date Module for Joomla--> 
<div style=" <?php echo $wrapperbox ?>">

	<div style=" <?php echo $month_setting ?>">
	<?php echo strftime("%b" ); ?>
	</div>
	<div style=" <?php echo $date_setting ?> ">
	<?php echo strftime("%d" ); ?>
	</div>
	<div style=" <?php echo $year_setting ?> ">
	<?php echo strftime("%Y" ); ?>
	</div>
	<?php if ($badgeuse == 1) {  ?> <div style=" <?php echo $badge_setting ?>"> <img src="modules/mod_calendar_date/<?php echo $badge_image ?>" alt="Today"/></div>
	<?php }?>

</div>